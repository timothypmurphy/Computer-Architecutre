extern int puts(const char *s);
extern int putchar(int c);

// y was -16 to +15
// x was 0 to 84

int main (int k){
  float i,j,r,x,y=-128;
  while (puts(""),y++<127)
    for (x=0;x++<256;putchar("2.`'-_~+^:;!/><= esp*&$%[]XQ@W#"[k&31]))
//    for (x=0;x++<168;putchar(" .:-;!/>)|&IH%*#"[k&15]))
      for(i=k=r=0;j=r*r-i*i-2+x/111,i=2*r*i+y/50,j*j+i*i<11&&k++<111;r=j);
//      for(i=k=r=0;j=r*r-i*i-2+x/25,i=2*r*i+y/10,j*j+i*i<11&&k++<111;r=j);
}
